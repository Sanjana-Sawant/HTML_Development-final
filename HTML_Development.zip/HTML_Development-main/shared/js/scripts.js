$(function(){
	$('#header').load('shared/header.html');
	$('#footer').load('shared/footer.html');	
});
